/**
 * 
 */
/**
 * 
 */
module book {
}